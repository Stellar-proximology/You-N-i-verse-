import React from 'react';
import GlyphSystem from '../components/GlyphSystem';
import FieldResonanceTracker from '../components/FieldResonanceTracker';

const Wet = () => {
  return (
    <div className="p-6 text-white bg-gradient-to-br from-black via-gray-900 to-gray-800 min-h-screen">
      <h1 className="text-3xl font-bold text-aura mb-4">🌊 W.E.T — Waveform Environment Tracker</h1>
      <FieldResonanceTracker />
      <GlyphSystem gates={[6, 36, 12, 11]} defined={[6, 36]} />
    </div>
  );
};

export default Wet;