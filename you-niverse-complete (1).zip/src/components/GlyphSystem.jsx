import React from 'react';

const GlyphSystem = ({ gates, defined }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {gates.map((gate, i) => {
        const isDefined = defined.includes(gate);
        return (
          <div key={gate} className={`p-4 rounded-lg border ${isDefined ? 'border-aura bg-aura text-black' : 'border-gray-500 bg-gray-900 text-gray-300'}`}>
            <h3 className="font-bold text-lg">Gate {gate}</h3>
            <p>{isDefined ? 'Defined' : 'Undefined'}</p>
            <div className="mt-2 text-2xl">
              {getGlyphForGate(gate)}
            </div>
          </div>
        );
      })}
    </div>
  );
};

const getGlyphForGate = (gate) => {
  const emojis = ['🔺', '🌀', '🌱', '💎', '🔥', '⚡', '🌕', '💧'];
  return emojis[gate % emojis.length];
};

export default GlyphSystem;