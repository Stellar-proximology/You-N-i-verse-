import React, { useState, useEffect } from 'react';

const FieldResonanceTracker = () => {
  const [coords, setCoords] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const geo = navigator.geolocation;
    if (!geo) return setError("Geolocation not supported");

    const watcher = geo.watchPosition(
      pos => setCoords({
        lat: pos.coords.latitude.toFixed(6),
        lon: pos.coords.longitude.toFixed(6),
        accuracy: pos.coords.accuracy
      }),
      err => setError(err.message),
      { enableHighAccuracy: true, maximumAge: 30000, timeout: 27000 }
    );

    return () => geo.clearWatch(watcher);
  }, []);

  return (
    <div className="mb-6 p-4 border border-aura rounded">
      <h2 className="text-xl font-semibold text-plasma mb-2">📍 Field Coordinates</h2>
      {error ? (
        <p className="text-red-500">Error: {error}</p>
      ) : coords ? (
        <ul className="text-sm">
          <li>Latitude: {coords.lat}</li>
          <li>Longitude: {coords.lon}</li>
          <li>Accuracy: ±{coords.accuracy} meters</li>
        </ul>
      ) : (
        <p>Fetching location...</p>
      )}
    </div>
  );
};

export default FieldResonanceTracker;