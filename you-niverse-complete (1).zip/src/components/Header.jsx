import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => (
  <header className="p-4 flex justify-between bg-black border-b border-aura">
    <h1 className="font-bold text-lg text-aura">YOU-NIVERSE</h1>
    <nav className="space-x-4">
      <Link to="/" className="hover:text-aura">Home</Link>
      <Link to="/dashboard" className="hover:text-aura">Dashboard</Link>
      <Link to="/birthday" className="hover:text-aura">Birthday</Link>
      <Link to="/glyph-lab" className="hover:text-aura">Glyph Lab</Link>
      <Link to="/wet" className="hover:text-aura">WET</Link>
    </nav>
  </header>
);

export default Header;