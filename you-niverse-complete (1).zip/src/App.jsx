import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import BirthdayChart from './pages/BirthdayChart';
import Wet from './pages/Wet';
import Header from './components/Header';

const App = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-gray-800 text-white">
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/birthday" element={<BirthdayChart />} />
        <Route path="/wet" element={<Wet />} />
      </Routes>
    </div>
  );
};

export default App;