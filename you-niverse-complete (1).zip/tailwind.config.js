module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        aura: "#00fff7",
        plasma: "#ff00cc",
      },
    },
  },
  plugins: [],
};